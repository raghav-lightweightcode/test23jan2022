<?php
/**
 * Silence is golden
 *
 * @package Librarybooksearch
 */