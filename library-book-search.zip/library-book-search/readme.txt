=== Library book search Plugin for WordPress -  Library Book Search ===
Tags: Library management system, library book search, library book finder
Requires at least: 4.5
Requires PHP: 5.6
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Library book search plugin that helps you to find the library books easily and in faster way.


== Description ==

